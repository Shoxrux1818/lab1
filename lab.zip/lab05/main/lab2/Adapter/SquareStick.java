package org.example.lab2.Adapter;

public class SquareStick {
    private int width;

    public SquareStick(int width) {
        this.width = width;
    }

    public int getWidth() {
        return width;
    }
}
