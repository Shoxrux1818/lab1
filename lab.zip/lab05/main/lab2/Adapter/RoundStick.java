package org.example.lab2.Adapter;

public class RoundStick {
    private int radius;

    public RoundStick(int radius) {
        this.radius = radius;
    }

    public RoundStick() {
    }

    public double getRadius() {
        return radius;
    }
}
