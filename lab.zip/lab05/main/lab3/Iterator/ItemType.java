package org.example.lab3.Iterator;

public enum ItemType {
    ANY, WEAPON, RING, POTION
}
