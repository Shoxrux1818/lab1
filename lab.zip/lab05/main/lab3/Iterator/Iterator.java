package org.example.lab3.Iterator;

public interface Iterator<T> {
    boolean hasNext();

    T next();
}
