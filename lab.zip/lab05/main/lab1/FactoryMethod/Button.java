package org.example.lab1.FactoryMethod;

public interface Button {
    void render();
}
