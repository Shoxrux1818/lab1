package org.example.lab1.FactoryMethod;

public interface Dialog {
    void render();
}
