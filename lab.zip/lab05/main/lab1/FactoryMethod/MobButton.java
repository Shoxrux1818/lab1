package org.example.lab1.FactoryMethod;

public class MobButton implements Button{
    public void render() {
        System.out.println("render MobButton");
    }
}
