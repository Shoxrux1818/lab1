package org.example.lab1.Builder;

public enum CarType {
        CITY_CAR, SPORTS_CAR, SUV
}
