package org.example.lab1.AbstractFabric;

public interface Input {
    void render();
    Input value(String value);
    String value();
}
