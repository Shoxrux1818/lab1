package org.example.lab1.AbstractFabric;

public interface Button {
    void render();
    void onClick();
}
