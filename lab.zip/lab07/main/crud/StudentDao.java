package org.example.crud;

import org.example.entities.Student;

public interface StudentDao extends CrudDao<Student, Long> {

}
